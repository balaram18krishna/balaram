import java.sql.*;
import java.util.Scanner;
public class Application {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		try
		{
			Class.forName(com.mysql.jdbc.Driver);
			
			Connection con = DriverManager.getconnection("jdbc:mysql://localhost/3306/balaramdb","root" , "root");
			
			if(con!=null)
			{
				System.out.println("connected Successfully");
				String name= sc.nextLine();
				int age = sc.nextInt();
				String branch = sc.nextLine();
				int year = sc.nextInt();
				int sem = sc.nextInt();
				double prevsemmarks = sc.nextDouble();
				String query = "INSERT INTO  studentdata VALUES" + "('name',age,'branch',year,sem,prevsemmarks)";
				
				Statement stmt = con.createStatement();
				int rowsaffected = stmt.executeUpdate(query);
				
				if(rowsaffected>0)
					System.out.println("inserted successfully");
				else
					System.out.println("not inserted successfully");
				
				String query1 = " select *from studentdata";
				
				ResultSet rs = stmt.executeQuery(query1);
				
				if(rs.next())
					System.out.println("students data is present");
				else 
					System.out.println("student data is not there");
				
				
			}
			else
				System.out.println("not connected");
		}
		
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
